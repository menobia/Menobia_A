package com.example.hp1.snakesandladders;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.Box;

import java.util.Random;

public class LevelOne extends AppCompatActivity {
    ImageButton die;
    int number;
    Random numb;
    int x;
    Box boxes[];
    int snakenladder[];
    ImageView s;
    ImageView s2;
    boolean snake1=false;
    boolean snake2=false;
    int slol;
    int chance=1; // to give chance to the player. 1= player 1 and 0 = computer
    TextView winner;
    int posplayerone=0; // initial position of player 1
    int posautoplayer=0; // initial position of automated
    int SorL1=0;// player 1
    int SorL2=0;// computer playing
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        boxes=new Box[100];  // for the positions of the boxes

        // for snakes and ladders , changing position according to snakes and ladder.
        snakenladder=new int[] {37,0,0,10,0,0,0,0,22,0,0,0,0,0,0,0,-10,0,0,0,21,0,0,0,0,0,0,56,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,16,0,0,-20,0,0,0,0,0,0,0,-43,0,-4,0,0,0,0,0,0,0,19,0,0,0,0,0,0,0,19,0,0,0,0,0,0,-51,0,0,0,0,0,-20,0,-20,0,0,-19,0,0};
        boxes[0]= new Box(52,1390);
        boxes[1]= new Box(187,1390);
        boxes[2]= new Box(320,1390);
        boxes[3]= new Box(450,1390);
        boxes[4]= new Box(580,1390);
        boxes[5]= new Box(710,1390);
        boxes[6]= new Box(840,1390);
        boxes[7]= new Box(970,1390);
        boxes[8]= new Box(1100,1390);
        boxes[9]= new Box(1230,1390);
        boxes[19]= new Box(52,1255);
        boxes[18]= new Box(187,1255);
        boxes[17]= new Box(320,1255);
        boxes[16]= new Box(450,1255);
        boxes[15]= new Box(580,1255);
        boxes[14]= new Box(710,1255);
        boxes[13]= new Box(840,1255);
        boxes[12]= new Box(970,1255);
        boxes[11]= new Box(1100,1255);
        boxes[10]= new Box(1230,1255);
        boxes[20]= new Box(52,1123);
        boxes[21]= new Box(187,1123);
        boxes[22]= new Box(320,1123);
        boxes[23]= new Box(450,1123);
        boxes[24]= new Box(580,1123);
        boxes[25]= new Box(710,1123);
        boxes[26]= new Box(840,1123);
        boxes[27]= new Box(970,1123);
        boxes[28]= new Box(1100,1123);
        boxes[29]= new Box(1230,1123);
        boxes[39]= new Box(52,990);
        boxes[38]= new Box(187,990);
        boxes[37]= new Box(320,990);
        boxes[36]= new Box(450,990);
        boxes[35]= new Box(580,990);
        boxes[34]= new Box(710,990);
        boxes[33]= new Box(840,990);
        boxes[32]= new Box(970,990);
        boxes[31]= new Box(1100,990);
        boxes[30]= new Box(1230,990);
        boxes[40]= new Box(52,860);
        boxes[41]= new Box(187,860);
        boxes[42]= new Box(320,860);
        boxes[43]= new Box(450,860);
        boxes[44]= new Box(580,860);
        boxes[45]= new Box(710,860);
        boxes[46]= new Box(840,860);
        boxes[47]= new Box(970,860);
        boxes[48]= new Box(1100,860);
        boxes[49]= new Box(1230,860);
        boxes[59]= new Box(52,730);
        boxes[58]= new Box(187,730);
        boxes[57]= new Box(320,730);
        boxes[56]= new Box(450,730);
        boxes[55]= new Box(580,730);
        boxes[54]= new Box(710,730);
        boxes[53]= new Box(840,730);
        boxes[52]= new Box(970,730);
        boxes[51]= new Box(1100,730);
        boxes[50]= new Box(1230,730);
        boxes[60]= new Box(52,600);
        boxes[61]= new Box(187,600);
        boxes[62]= new Box(320,600);
        boxes[63]= new Box(450,600);
        boxes[64]= new Box(580,600);
        boxes[65]= new Box(710,600);
        boxes[66]= new Box(840,600);
        boxes[67]= new Box(970,600);
        boxes[68]= new Box(1100,600);
        boxes[69]= new Box(1230,600);
        boxes[79]= new Box(52,470);
        boxes[78]= new Box(187,470);
        boxes[77]= new Box(320,470);
        boxes[76]= new Box(450,470);
        boxes[75]= new Box(580,470);
        boxes[74]= new Box(710,470);
        boxes[73]= new Box(840,470);
        boxes[72]= new Box(970,470);
        boxes[71]= new Box(1100,470);
        boxes[70]= new Box(1230,470);
        boxes[80]= new Box(52,340);
        boxes[81]= new Box(187,340);
        boxes[82]= new Box(320,340);
        boxes[83]= new Box(450,340);
        boxes[84]= new Box(580,340);
        boxes[85]= new Box(710,340);
        boxes[86]= new Box(840,340);
        boxes[87]= new Box(970,340);
        boxes[88]= new Box(1100,340);
        boxes[89]= new Box(1230,340);
        boxes[99]= new Box(52,210);
        boxes[98]= new Box(187,210);
        boxes[97]= new Box(320,210);
        boxes[96]= new Box(450,210);
        boxes[95]= new Box(580,210);
        boxes[94]= new Box(710,210);
        boxes[93]= new Box(840,210);
        boxes[92]= new Box(970,210);
        boxes[91]= new Box(1100,210);
        boxes[90]= new Box(1230,210);



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level_one);
        die=(ImageButton)findViewById(R.id.imageButton);
        s= (ImageView) findViewById(R.id.blueplayer);
        s2= (ImageView) findViewById(R.id.redplayer);
        winner= (TextView) findViewById(R.id.winner);
        numb= new Random();
        winner.setText("Player 1's turn");

        die.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number=numb.nextInt(6)+1;
                if(number==1)
                {
                    die.setImageResource(R.drawable.one);
                }
                else if(number==2)
                {
                    die.setImageResource(R.drawable.two);
                }
                else if(number==3)
                {
                    die.setImageResource(R.drawable.three);
                }
                else if(number==4)
                {
                    die.setImageResource(R.drawable.four);
                }
                else if(number==5)
                {
                    die.setImageResource(R.drawable.five);
                }
                else if(number==6)
                {
                    die.setImageResource(R.drawable.six);
                }
                if((posplayerone==100)||(posautoplayer==100))// if any of player's position is 100 return chance;
                { winner.setText("PLAYER "+chance+" WINS");
                    return;}
                if (chance==1) {
                    if (snake1==true&&number==6){
                        snake1=false;
                    }
                    if(snake1==false) {
                        posplayerone = posplayerone + number;
                        SorL1 = snakenladder[posplayerone - 1];
                        if (posplayerone >= 100) {
                            winner.setText("CAN'T MOVE");
                            posplayerone = posplayerone - number;
                        } else {
                            posplayerone = posplayerone + snakenladder[posplayerone - 1];
                            s.setX(boxes[posplayerone - 1].X);
                            s.setY(boxes[posplayerone - 1].Y);
                        }
                    }
                    if (SorL1<0){
                        snake1=true;
                    }
                    if (number!=6&&SorL1<=0){
                    chance=0;
                    winner.setText("Computer's turn");
                    return;}
                }
                if (chance==0) {
                    if (snake2==true&&number==6){
                        snake2=false;
                    }
                    if(snake2==false) {
                        posautoplayer = posautoplayer + number;
                        SorL2 = snakenladder[posautoplayer - 1];
                        if (posautoplayer >= 100) {
                            winner.setText("CAN'T MOVE");
                            posautoplayer = posautoplayer - number;
                        } else {
                            posautoplayer = posautoplayer + snakenladder[posautoplayer - 1];
                            s2.setX(boxes[posautoplayer - 1].X + 36);
                            s2.setY(boxes[posautoplayer - 1].Y);
                        }
                    }
                    if (SorL2<0){
                        snake2=true;
                    }
                    if (number!=6&& SorL2<=0) {
                        chance = 1;
                        winner.setText("Player 1's turn");
                        return;
                    }

                }
            }
        });
    }

}
