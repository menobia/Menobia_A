package com;

/**
 * Created by hp 1 on 3/17/2017.
 */
public class Box {
    public int X;
    public int Y;

    public Box(int x,int y)
    {
        X=x;
        Y=y;
    }
}
